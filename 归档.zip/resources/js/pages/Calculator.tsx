import { useState } from 'react';
import { Head } from '@inertiajs/react';
import FrontendLayout from '@/layouts/frontend-layout';

type Result = 'P' | 'B';

interface RoadCell {
    result: Result;
    row: number;
    col: number;
}

export default function Calculator() {
    const [results, setResults] = useState<Result[]>([]);
    const [roadMap, setRoadMap] = useState<RoadCell[]>([]);

    const addResult = (result: Result) => {
        const newResults = [...results, result];
        setResults(newResults);
        
        // Generate roadmap
        const newRoadMap = generateRoadMap(newResults);
        setRoadMap(newRoadMap);
    };

    const generateRoadMap = (results: Result[]): RoadCell[] => {
        const roadMap: RoadCell[] = [];
        let currentCol = 0;
        let currentRow = 0;
        let lastResult: Result | null = null;
        let streakStartCol = 0; // Track where the current streak started

        for (let i = 0; i < results.length; i++) {
            const result = results[i];
            
            if (lastResult === null || lastResult !== result) {
                // Different result - need to start a new column
                if (lastResult !== null) {
                    // New streak starts right after the start of the previous streak
                    currentCol = streakStartCol + 1;
                    currentRow = 0;
                    streakStartCol = currentCol; // Update streak start position
                }
            } else {
                // Same result - continue the streak
                
                // Helper function to check if a position is occupied
                const isPositionOccupied = (col: number, row: number) => {
                    return roadMap.some(cell => cell.col === col && cell.row === row);
                };
                
                // Try to continue vertically first
                const nextRow = currentRow + 1;
                
                if (nextRow < 6 && !isPositionOccupied(currentCol, nextRow)) {
                    // Can continue down in the same column
                    currentRow = nextRow;
                } else {
                    // Can't go down, need to go right and stay in the same row
                    currentCol++;
                    
                    // Stay in the same row when going horizontally
                    // If current row is occupied, find the first available row from bottom up
                    if (isPositionOccupied(currentCol, currentRow)) {
                        for (let testRow = 5; testRow >= 0; testRow--) {
                            if (!isPositionOccupied(currentCol, testRow)) {
                                currentRow = testRow;
                                break;
                            }
                        }
                    }
                    // If current row is not occupied, stay in the same row
                }
            }
            
            roadMap.push({
                result,
                row: currentRow,
                col: currentCol
            });
            
            lastResult = result;
        }
        
        return roadMap;
    };

    const clearResults = () => {
        setResults([]);
        setRoadMap([]);
    };

    // Create grid for display - always show rightmost 15 columns
    const maxRows = 6;
    const displayCols = 15;
    const totalCols = roadMap.length > 0 ? Math.max(...roadMap.map(cell => cell.col)) + 1 : 0;
    const startCol = Math.max(0, totalCols - 10); // Show rightmost 10 columns with data, plus 5 empty

    return (
        <FrontendLayout>
            <Head title="百家乐路单" />
            
            <div className="min-h-screen bg-gray-50 p-4">
                <div className="max-w-md mx-auto">
                    {/* Header */}
                    <div className="text-center mb-6">
                        <h1 className="text-2xl font-bold text-gray-800 mb-2">百家乐路单</h1>
                        <p className="text-sm text-gray-600">点击 P 或 B 记录结果</p>
                    </div>

                    {/* Control Buttons */}
                    <div className="flex gap-4 mb-6">
                        <button
                            onClick={() => addResult('P')}
                            className="flex-1 bg-red-500 hover:bg-red-600 text-white font-bold py-4 px-6 rounded-lg text-xl transition-colors"
                        >
                            P 庄
                        </button>
                        <button
                            onClick={() => addResult('B')}
                            className="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold py-4 px-6 rounded-lg text-xl transition-colors"
                        >
                            B 闲
                        </button>
                    </div>

                    {/* Clear Button */}
                    <div className="text-center mb-6">
                        <button
                            onClick={clearResults}
                            className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg text-sm transition-colors"
                        >
                            清空路单
                        </button>
                    </div>

                    {/* Road Map Grid */}
                    <div className="bg-white rounded-lg p-4 shadow-sm border">
                        <h3 className="text-lg font-semibold mb-4 text-center">大路</h3>
                        <div 
                            className="grid gap-1"
                            style={{ 
                                gridTemplateColumns: `repeat(${displayCols}, 24px)`,
                                gridTemplateRows: `repeat(${maxRows}, 24px)`
                            }}
                        >
                            {Array.from({ length: maxRows * displayCols }).map((_, index) => {
                                const row = Math.floor(index / displayCols);
                                const displayCol = index % displayCols;
                                const actualCol = startCol + displayCol;
                                
                                const cell = roadMap.find(c => c.row === row && c.col === actualCol);
                                
                                return (
                                    <div
                                        key={index}
                                        className={`w-6 h-6 border border-gray-200 rounded-sm flex items-center justify-center text-xs font-bold ${
                                            cell 
                                                ? cell.result === 'P' 
                                                    ? 'bg-red-500 text-white' 
                                                    : 'bg-blue-500 text-white'
                                                : 'bg-gray-50'
                                        }`}
                                    >
                                        {cell ? cell.result : ''}
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* Results Summary */}
                    {results.length > 0 && (
                        <div className="mt-6 bg-white rounded-lg p-4 shadow-sm border">
                            <h3 className="text-lg font-semibold mb-2">统计</h3>
                            <div className="flex justify-between text-sm">
                                <span>总局数: {results.length}</span>
                                <span>庄: {results.filter(r => r === 'P').length}</span>
                                <span>闲: {results.filter(r => r === 'B').length}</span>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </FrontendLayout>
    );
}