# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Development Commands

### Backend (Laravel)
- `composer dev` - Start development environment (Laravel server, queue worker, logs, and Vite)
- `composer dev:ssr` - Start development with SSR support
- `composer test` - Run PHPUnit tests with config clear
- `php artisan serve` - Start Laravel development server
- `php artisan test` - Run tests
- `php artisan migrate` - Run database migrations
- `php artisan pail` - View application logs in real-time

### Frontend (React + TypeScript)
- `npm run dev` - Start Vite development server
- `npm run build` - Build for production
- `npm run build:ssr` - Build with SSR support
- `npm run lint` - Run ESLint with auto-fix
- `npm run types` - Run TypeScript type checking
- `npm run format` - Format code with Prettier
- `npm run format:check` - Check code formatting

## Architecture Overview

### Technology Stack
- **Backend**: Laravel 12 with Inertia.js
- **Frontend**: React 19 with TypeScript
- **Styling**: Tailwind CSS 4 with Radix UI components
- **Database**: SQLite (development)
- **Build Tool**: Vite 6

### Key Application Features
This is a Laravel-React marketplace application with:
- User authentication with email verification
- Biometric authentication (WebAuthn)
- House/property listings with status management
- Order management system with buyer/seller workflows  
- Referral system with commission tracking
- User wallet/earnings system
- Profile management with avatar uploads
- Seller application system

### Core Models & Relationships
- **User**: Central model with referral system, houses, orders, earnings
- **House**: Property listings with status (pending, approved, sold, suspended)
- **Order**: Complex workflow (pending → confirmed → shipped → delivered → completed)
- **OrderMessage**: Communication between buyers and sellers
- **ReferralCommission**: Commission tracking for referrals
- **Earning**: User earnings from various sources
- **UserCredential**: Biometric authentication credentials

### Frontend Structure
- **Pages**: Organized by feature (auth/, houses/, profile/, settings/)
- **Components**: Reusable UI components with Radix UI primitives
- **Layouts**: Nested layouts (app, auth, settings with sidebars)
- **Hooks**: Custom hooks for appearance, mobile detection, user data
- **Utils**: Utility functions for biometric auth and general helpers

### API Structure
- RESTful APIs under `/api/` prefix
- Authenticated routes require `auth` and `verified` middleware
- Key endpoints: houses, orders, referrals, wallet, profile, settings
- Separate biometric auth endpoints under `/api/biometric/`

### Database Schema
- Uses enum fields for status management (orders, houses)
- Comprehensive migration history showing feature evolution
- Referral system with codes and commission tracking
- User profile fields including social contacts (WeChat, WhatsApp)

### Testing
- PHPUnit configuration with Feature and Unit test suites
- Uses SQLite in-memory database for tests
- Existing tests cover authentication flows and basic functionality

## Development Notes

### Order Status Flow
Orders follow a complex state machine:
pending → confirmed → shipped → delivered → completed
With possible states: rejected, cancelled_by_buyer, cancelled_by_seller, rejected_delivery

### House Status Management  
Houses can be: pending, approved, sold, suspended
With special logic for relisting and time updates

### Biometric Authentication
Implements WebAuthn for passwordless authentication with credential management

### Referral System
Each user has a unique referral code and can earn commissions from referred users